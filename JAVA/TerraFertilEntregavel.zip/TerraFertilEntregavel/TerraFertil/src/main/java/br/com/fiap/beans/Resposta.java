package br.com.fiap.beans;

public class Resposta extends Forum{

	private Boolean aceitacao;

	public Boolean getAceitacao() {
		return aceitacao;
	}

	public void setAceitacao(Boolean aceitacao) {
		this.aceitacao = aceitacao;
	}

	
}