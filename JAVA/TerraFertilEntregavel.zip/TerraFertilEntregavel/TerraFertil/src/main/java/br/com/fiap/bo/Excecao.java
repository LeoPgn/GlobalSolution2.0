package br.com.fiap.bo;

public class Excecao extends Exception {

	/**
	 * @author regina
	 * @author matheus
	 */
	private static final long serialVersionUID = 1L;

	public Excecao(String recebe) {	
	}
}