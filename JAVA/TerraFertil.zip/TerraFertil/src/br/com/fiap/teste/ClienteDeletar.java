package br.com.fiap.teste;

import java.sql.Connection;

import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.Conexao;
import br.com.fiap.dao.ClienteDAO;


public class ClienteDeletar {

	public static void main(String[] args) {

		Connection con = Conexao.abrirConexao();

		Cliente cliente = new Cliente();
		ClienteDAO clientedao = new ClienteDAO(con);

		// Testando o m�todo deletar
		cliente.setNome("Regina");
		System.out.println(clientedao.deletar(cliente));

		Conexao.fecharConexao(con);
	}
}
