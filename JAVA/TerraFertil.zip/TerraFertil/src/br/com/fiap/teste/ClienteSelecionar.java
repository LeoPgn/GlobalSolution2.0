package br.com.fiap.teste;

import java.sql.Connection;
import java.util.ArrayList;

import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.Conexao;
import br.com.fiap.dao.ClienteDAO;

public class ClienteSelecionar {

	public static void main(String[] args) {

		Connection con = Conexao.abrirConexao();

		ClienteDAO clientedao = new ClienteDAO(con);

		// Listar
		ArrayList<Cliente> lista = clientedao.retornarDados();

		if (lista != null) {
			for (Cliente c : lista) {
				System.out.println("Nome: " + c.getNome());
				System.out.println("Cpf: " + c.getCpf() + "\n");
			}
		}

		Conexao.fecharConexao(con);
	}

}
