package br.com.fiap.teste;

import java.sql.Connection;

import br.com.fiap.beans.Cliente;
import br.com.fiap.bo.ClienteBO;
import br.com.fiap.bo.Excecao;
import br.com.fiap.conexao.Conexao;

public class ClienteInserirBO {

	public static void main(String[] args) throws Excecao {

			Connection con = Conexao.abrirConexao();

			Cliente cliente = new Cliente();
			// PessoaDAO pessoadao = new PessoaDAO(con);
			ClienteBO clientebo = new ClienteBO();

			// Testando o m�todo inserir
			cliente.setNome("stella");
			cliente.setEmail("jhonn@gmail");
			cliente.setSenha("lalalala");
			cliente.setCpf("12345678970");
			cliente.setCnpj("12345678910234");
			cliente.setDataNascimento("28/04/1997");
			cliente.setTelefone("119017662");
			cliente.setCep("02535001");
			clientebo.inserirBO(cliente);

			
			Conexao.fecharConexao(con);
		}

	}

