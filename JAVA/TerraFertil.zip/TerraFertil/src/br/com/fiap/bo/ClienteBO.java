package br.com.fiap.bo;

import java.sql.Connection;

import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.Conexao;
import br.com.fiap.dao.ClienteDAO;

public class ClienteBO {

	Connection con = Conexao.abrirConexao();

	ClienteDAO clientedao = new ClienteDAO(con);


	// regra de neg�cio - Business Object
	public void inserirBO(Cliente cliente) throws Excecao {
		if ((cliente.getCpf().length() > 11) || (cliente.getCep().length() < 8) || 
			(cliente.getCnpj().length() > 14) || (cliente.getSenha().length() < 8)) {
			System.out.println("Quantidade de caracteres " + "do cpf/cep/cnpj/senha" + " não atende o mínimo");
		} else {
			cliente.setCpf(cliente.getCpf());
			cliente.setCep(cliente.getCep());
			cliente.setCnpj(cliente.getCnpj());
			cliente.setSenha(cliente.getSenha());
			System.out.println(clientedao.inserir(cliente));
		}
	}
}
