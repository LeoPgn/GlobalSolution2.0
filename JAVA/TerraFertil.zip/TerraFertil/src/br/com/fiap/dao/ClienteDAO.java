package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.beans.Cliente;


public class ClienteDAO {

	private Connection con;

	public final Connection getCon() {
		return con;
	}

	public final void setCon(Connection con) {
		this.con = con;
	}

	public ClienteDAO(Connection con) {
		setCon(con);
	}

	public String inserir(Cliente cliente) {
		String sql = "insert into cliente(cliente_nome, email, cpf, cnpj, senha, data_nasc, contato, cep) values (?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, cliente.getNome());
			ps.setString(2, cliente.getEmail());
			ps.setString(3, cliente.getCpf());
			ps.setString(4, cliente.getCnpj());
			ps.setString(5, cliente.getSenha());
			ps.setString(6, cliente.getDataNascimento());
			ps.setString(7, cliente.getTelefone());
			ps.setString(8, cliente.getCep());
			if (ps.executeUpdate() > 0) {
				return "Inserido com sucesso";
			} else {
				return "Erro ao inserir";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}

	// M�todo deletarDois utilizando o delete com o where para endereco

	public String deletar(Cliente cliente) {
		String sql = "delete from cliente where cliente_nome = ?";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, cliente.getNome());
			if (ps.executeUpdate() > 0) {
				return "Deletado com sucesso";
			} else {
				return "Erro ao deletar";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}

	// Utilizando o select
	public ArrayList<Cliente> retornarDados() {
		String sql = "select * from cliente";
		ArrayList<Cliente> retornarCliente = new ArrayList<Cliente>();
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			// int idade = 36;
			ResultSet rs = ps.executeQuery();// ResultSet � uma instru��o do Java
			if (rs != null) {
				while (rs.next()) {
					Cliente cliente = new Cliente();
					cliente.setNome(rs.getString(1));
					cliente.setCpf(rs.getString(2));
					retornarCliente.add(cliente);
				}
				return retornarCliente;
			} else {
				return null;
			}
		} catch (SQLException e) {
			return null;
		}
	}
}